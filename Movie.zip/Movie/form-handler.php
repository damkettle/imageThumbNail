<!DOCTYPE HTML>  
<html>
<head>
</head>
<body>  


<?php
// define variables and set to empty values
$title = $name= $address = $phone = $email = $gender = $contactmethod = $comments = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $title = test_input($_POST["title"]);
  $name = test_input($_POST["name"]);
  $address = test_input($_POST["address"]);
  $email = test_input($_POST["email"]);
  $phone = test_input($_POST["phone"]);
  $gender = test_input($_POST["gender"]);
  $contactmethod = test_input($_POST["method"]);
  $comments = test_input($_POST["comments"]);
}

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}

?>

<?php
echo "<h2>Your Input:</h2>";
echo $title;
echo "<br>";
echo $name;
echo "<br>";
echo $address;
echo "<br>";
echo $email;
echo "<br>";
echo $phone;
echo "<br>";
echo $gender;
echo "<br>";
echo $contactmethod;
echo "<br>";
echo $comments;
?>

</body>
</html>